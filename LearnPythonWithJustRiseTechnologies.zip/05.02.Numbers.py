#Operators + / * - %


a=10
b=5
c=a+b

add= 10+5
sub=5-10
mult=5*2
div=10/5
mod=11%5

print('Direct Variable',add,' Indirect Variable', c,' Multi:', mult,' Sub:', sub,' Div: ',div, ' Mod:',mod)