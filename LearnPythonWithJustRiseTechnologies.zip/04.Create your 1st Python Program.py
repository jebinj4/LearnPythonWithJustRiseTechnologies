# Example 1

name='Jebin'
print(name)

# ----------------------------------------
# Example 2
name=input('What is your name?')
print('Your Name is ' + name)

# `print(name)` is printing the value of the variable `name` to the console.
# print(name)
