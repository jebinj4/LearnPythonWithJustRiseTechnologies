#decission taker

a=10
b=5


print(a==b)
print(a!=b)
print(a>b)
print(a<b)

#----Using Methods need more referance 
print('Jebin'.endswith('a'))
print('Jebin'.endswith('n'))
