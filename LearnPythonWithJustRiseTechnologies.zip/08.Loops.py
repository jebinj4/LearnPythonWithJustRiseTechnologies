# car=['a','b','c']

# print(len(car))
# print(car)
# print(car[0])
# print(car[1])
# print(car[2])

cars=['a','b','c','jebin']

for car in cars:
    print(car)
    
for car in cars:
    print(car.upper())
    print('--------------')
    
for car in cars:
    if car=='jebin':
        print(car.capitalize())