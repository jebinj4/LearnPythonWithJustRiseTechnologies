First_name='jose'
Last_name='jose'
name=First_name+' '+Last_name
print (name)
print (len(name))
print ((name.capitalize()))
print ((name.upper()))

#----Methods need more referance 