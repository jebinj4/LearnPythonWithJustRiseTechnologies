# Basic Python Tutorials :https://www.youtube.com/watch?v=picCusmKDs0&list=PLwvrYc43l1MzSBvslCMVZGtLLaZTq3VTG&index=11

# Depth Python Tutorials: https://www.youtube.com/watch?v=KOdfpbnWLVo&list=PLi01XoE8jYohWFPpC17Z-wWhPOSuh8Er-