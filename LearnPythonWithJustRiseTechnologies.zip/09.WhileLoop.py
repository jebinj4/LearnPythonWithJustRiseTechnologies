num=0

while num<=10 :
    print('Here is the value for num:',str(num))
    num=num+1
    print('Here is the value for num:',str(num))
else:
    print('Loop ended with ', num)