car=['a','b','c']

print(len(car))
print(car)
print(car[0])
print(car[1])
print(car[2])


