# Example 1

is_adult=True

if is_adult:
    print('This kids are adult')
    

# Example 2

a=5
b=6

if a==b:
    print('A and B are Equal')
else:
    print('A and B are Not Equal')
    

